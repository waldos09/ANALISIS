# -*- coding: utf-8 -*-
"""
Created on Sat Apr  2 17:35:40 2022

@author: waldo
"""

def spotify_user_id():
    return '2234g6eigg2jew5ptbff2sfka'

def spotify_token():
    return 'BQAgts9wTJHXUBlXTYGzAPgoxk6djSpw0JzkpmzMLZ1RINpJzwuM81sZtysL-QIHCxy3x4Fj3BUfw_yKZZ_GtRvUsIJ9eF_hf3OPUM2ZAXUwc9Pi0PmfDY__c_XRzBWz96heRdb1sj7e0L0gL5kNZGScv3SaIXl9ee7SnNLujS9TSIMhOpvCnKPLkCOUcT32JOw'

def last_fm_api_key():
    return '78817666f22a37eb970d11e179d0c919'



""" 
Borrar despues
Application name	SpotAPI
API key	78817666f22a37eb970d11e179d0c919
Shared secret	a84985026803e4b18cdb4d42cc3c5717
Registered to	WaldosTech

"""