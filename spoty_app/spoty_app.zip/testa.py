# -*- coding: utf-8 -*-
"""
Created on Sat Apr  2 18:12:07 2022

@author: waldo
"""
def suma(a,b):
    return a+b